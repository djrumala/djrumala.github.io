Please kindly check my website djrumala.github.io

See the original post for this for more information:
https://djrumala.github.io/posts/2023/09/blog-post-2/
